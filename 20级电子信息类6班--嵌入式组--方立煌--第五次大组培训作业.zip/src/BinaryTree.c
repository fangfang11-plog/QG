#include<stdio.h>
#include"BinaryTree.h"
#include"function.h"




status BST_init(BinarySortTreePtr* T) {


    if ((*T)) {

		return failed ;

	}
	else {
		(*T) = (BinarySortTreePtr)malloc(sizeof(BinarySortTree));
	
		if (!(*T)) {
		
			exit(0);
		
		}
		else {

		(*T)->root = NULL;
        return succeed;
		
		}
	}
}


//����������������
status BST_insert(BinarySortTreePtr T, ElemType e)
{
	
	if (!T) {
		
		return failed;

	}
	else if (!T->root) {
	
		T->root = (NodePtr)malloc(sizeof(Node));
		if (!T->root)exit(0);
		T->root->value = e;
		T->root->left = NULL;
		T->root->right = NULL;
		return succeed;

	}
	else if (BST_search(T, e) == 1) {
	
		return failed;//�����н��ֵʱ�Զ��˳�
	
	}
	else{

		NodePtr Traverse = T->root;
		
		while (1) {
			
			if (e < Traverse->value) {
				if (Traverse->left) {

					Traverse = Traverse->left;

				}
				else if (!Traverse->left) {

					NodePtr newn = (NodePtr)malloc(sizeof(Node));
					if (!newn)exit(0);
					newn->value = e;
					Traverse->left = newn;
					newn->left = NULL;
					newn->right = NULL;
					break;
				}
			}

			if (e > Traverse->value) {
				
				if ( Traverse->right ) {
					
					Traverse = Traverse->right;

				}
				else if (!Traverse->right)
				{

					NodePtr newn = (NodePtr)malloc(sizeof(Node));
					if (!newn)exit(0);
					newn->value = e;
					Traverse->right = newn;
					newn->left = NULL;
					newn->right = NULL;
					break;
				}
			}
			
		}
		return succeed;
	}

}


//ɾ�����
status BST_delete(BinarySortTreePtr T, ElemType e) {

	if (!T||!T->root) {

		return failed;
	
	}
	else if (BST_search(T, e) == 0) {
		
		return failed;//���޶�Ӧ���
	
	}
	else {//�иý��ʱ����ɾ��

		NodePtr temp = T->root;
		NodePtr Traverse = T->root;

		int flag = 0;

		while (1) {

			if (e < Traverse->value) {
				temp = Traverse;
			    Traverse = Traverse->left;
				flag = 1;

			}

			if (e > Traverse->value) {
				temp = Traverse;
			    Traverse = Traverse->right;
				flag = 2;
			}


			if (e == Traverse->value) {//�ҵ����

				if (!Traverse->left&&!Traverse->right) {
				
					if (flag == 1) {//
						temp->left = NULL;
					}
					else if (flag == 2) {
						temp->right = NULL;
					}

				}
				else if(Traverse->left&&!Traverse->right) {
					
					if (flag == 1) {//
						temp->left = Traverse->left;
					}
					else if (flag == 2) {
						temp->right = Traverse->left;
					}

				}
				else if (!Traverse->left && Traverse->right) {
					if (flag == 1) {//
						temp->left = Traverse->left;
					}
					else if (flag == 2) {
						temp->right = Traverse->right;
					}					

				}
				else if (Traverse->left && Traverse->right) {
					NodePtr alt = NULL;
					NodePtr p = Traverse->left;//�����������н���ȡ���
					
					while (p->right) {
						alt = p;
						p = p->right;
					}

					alt->right = NULL;
					if (flag == 1) {//
						temp->left = p;
					}
					else if (flag == 2) {
						temp->right = p;
					}
					p->left = Traverse->left;
					p->right = Traverse->right;

				}
				if (Traverse == T->root) {
					free(T->root);//�ͷŽڵ�
					T->root = NULL;
				}
				else {
					free(Traverse);
					Traverse = NULL;
				}
		        return succeed;

			}

		}
	}

}



//���ַ�ʵ�ֲ���
status BST_search(BinarySortTreePtr T, ElemType e) {

	if (!T || !(T->root)) {
		return failed;
	}
	else {
		NodePtr Traverse = T->root;
		while (1) {
			if (e < Traverse->value) {
				if (Traverse->left) {
                    Traverse = Traverse->left;
				
				}
				else if (!Traverse->left) {
                	return failed;//�����ڷ���failed

				}

			}

			if (e > Traverse->value) {
				if (Traverse->right) {
                    Traverse = Traverse->right;

				}
				else if (!Traverse->right)
				{
					return failed;

				}
			}

			if (e == Traverse->value) {

				return succeed;
			
			}

		}
	}


}


//�ݹ�����
status BST_preorderR(BinarySortTreePtr T, void (*visit)(NodePtr p)) {
	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		PreOrderTraverse(T->root,visit);
	}
	back();
	return succeed;
}


//��������
status BST_preorderI(BinarySortTreePtr T, void (*visit)(NodePtr)) {
	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		int count = 0;
			LinkStack* S = NULL;
			Stack_Init(&S);
			Stack_Push(&S, T->root);
			while (!Stack_Empty(S)) {
				NodePtr node = Stack_Top(S);
				if (!node) {
					continue;
				}
				visit(node);
				count++;
				if (count != 0 && count % 5 == 0) {
					toxy(48, 12 + count / 5);
				}
				Stack_Pop(&S);
				if (node->right) {
					Stack_Push(&S, node->right);
				}
				if (node->left) {
					Stack_Push(&S, node->left);
				}
			}
			free(S);
			S = NULL;
			back();
			return succeed;
	}
}

//�ݹ�����
status BST_inorderR(BinarySortTreePtr T, void (*visit)(NodePtr)) {
	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		InOrderTraverse(T->root, visit);
		back();
	    return succeed;
	}
}


//��������
status BST_inorderI(BinarySortTreePtr T, void (*visit)(NodePtr)) {
	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		int count = 0;
		LinkStack* S = NULL;
		Stack_Init(&S);
		Node* p = T->root;
		while (p||!Stack_Empty(S)) {

			while (p) {
				Stack_Push(&S, p);
				p = p->left;
			}


			if (!Stack_Empty(S)) {
				p = Stack_Top(S);
				Stack_Pop(&S);
				visit(p);
				count++;
				if (count != 0 && count % 5 == 0) {
					toxy(48, 12 + count / 5);
				}
				p = p->right;
			}

		}
		free(S);
		S = NULL;
    //���������
	//������ջ
	//������ΪNULLʱ��ջ
	//һ����ջ���һ���Ƿ�����Һ�
	//����ʱ�����Һ����Һ���ջ
	//���Һ�����ѭ������
			//if (p->right) {
			//	visit(p);//��ӡջ��
			//	Stack_Pop(&S);
			//	p = p->right;
			//	Stack_Push(&S, p);
			//}
		//while (!Stack_Empty(S)) {
		//	NodePtr node = Stack_Top(S);
		//	if (!node) {//��Ը��ڵ�����
		//		Stack_Pop(&S);
		//		continue;
		//	}
		//	if (node->left) {//�������
		//		Stack_Push(&S, node->left);
		//	}
		//	else {//��С���
		//		while (1) {//����ʱ���з���
		//			if (node)//��ֹ���ڵ㵼��NULLָ������� 
		//			{
		//				if (node->right) {
		//			        visit(node);//��һ�η���
		//					Stack_Push(&S, node->right);
		//					break;//�������ʱ�ӳ�����,��������
		//				} 
		//				else {//��ȼ�С���㣬�ص�����
		//					visit(node);
		//					Stack_Pop(&S);
		//					Stack_Pop(&S);
		//					node=Stack_Top(&S);
		//				}

		//			}
		//			else {
		//				break;
		//			}
		//		}

		//	}

		//}

	}
	back();
}


//�ݹ����
status BST_postorderR(BinarySortTreePtr T, void (*visit)(NodePtr)) {
	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		PostOrderTraverse(T->root, visit);
		back();
		return succeed;
	}
}


//��������
status BST_postorderI(BinarySortTreePtr T, void (*visit)(NodePtr)) {
//ʵ�ַ������󺢴���ʱ����ջ�������
//�󺢲����ڣ�����Һ����Һ�����ʱ�������ظ�����
//�������Һ�ʱ����ջ���лع飬��С���ͬʱ����Һ�
//�Һ��������������

	if (false_reminder(T) == 1) {
		back();
		return failed;
	}
	else {
		int count = 0;
		//��������������������ջ��
		LinkStack* S = NULL;
		Stack_Init(&S);
		Node* p = T->root;
		Node* temp = NULL;
		while (p||!Stack_Empty(S)) {
				while (p) {
					Stack_Push(&S, p);
					p = p->left;
				}
				p = Stack_Top(S);
				S->top->cishu++;
				if (p->right&&S->top->cishu==2) {
					p = p->right;
				}
				else {
					visit(p);
					count++;
					if (count != 0 && count % 5 == 0) {
						toxy(48, 12 + count / 5);
					}
					Stack_Pop(&S);
					p = NULL;
				}
		}
		free(S);
		S = NULL;

	}
//������������
		//LinkStack* S = NULL;
		//Stack_Init(&S);
		//Stack_Push(&S, T->root);
		//while (!Stack_Empty(S)) {
		//	NodePtr node = Stack_Top(S);//����ջ���������ı���
		//	if (node->left) {
		//		Stack_Push(&S, node->left);
		//		break;
		//	}
		//	else {
		//		while (1) {
		//			if (node->right) {
		//				Stack_Push(&S, node->right);//�������
		//				break;
		//			}
		//			else {
		//				visit(node);
		//				Stack_Pop(&S);
		//				node = Stack_Top(S);

		//			}
		//		}
		//	}

		//}
	back();
}


//����
status BST_levelOrder(BinarySortTreePtr T, void (*visit)(NodePtr)) 
{
	if (false_reminder(T) == 1) {
		_getch();
		return failed;
	}
	else {
		int count = 0;
		LQueue* Q = NULL;
		Queue_Init(&Q);
		Queue_In(&Q, T->root);
		while (!Queue_Empty(Q)) {
			NodePtr node = Queue_Front(Q);
			if (!node) {
				Queue_Out(&Q);
				continue;
			}
			visit(node);
			count++;
			if (count != 0 && count % 5 == 0) {
				toxy(48, 12 + count / 5);
			}
			Queue_Out(&Q);
			if (node->left) {
				Queue_In(&Q, node->left);
			}
			if (node->right) {
				Queue_In(&Q, node->right);
			}
		}
	free(Q);
	Q = NULL;
	}
	back();
}
