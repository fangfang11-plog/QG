#include<stdio.h>
#include"BinaryTree.h"


int main() {

    BinarySortTreePtr T = NULL;
	BST_init(&T);
	menu_main(T);
	return 0;
}   