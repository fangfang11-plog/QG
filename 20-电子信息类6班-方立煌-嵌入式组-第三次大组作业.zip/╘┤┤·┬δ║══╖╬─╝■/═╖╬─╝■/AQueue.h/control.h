#pragma once
#include"AQueue.h"
void quence_function(AQueue* Q);
void back(AQueue* Q);
void init_function(AQueue* Q);
void destory_function(AQueue* Q);
void clear_function(AQueue* Q);
void isempty_function(AQueue* Q);
void isfull_function(AQueue* Q);
void traverse_function(AQueue* Q);
void getfront_function(AQueue* Q);
void enter_function(AQueue* Q);
void delete_function(AQueue* Q);
void length_function(AQueue* Q);
int input(int min, int max);
void clear();//����