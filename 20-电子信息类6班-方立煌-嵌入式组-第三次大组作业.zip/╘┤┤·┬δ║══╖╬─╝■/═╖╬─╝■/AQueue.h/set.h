#pragma once
void HideCursor();
void color(short x);
void toxy(int x, int y);