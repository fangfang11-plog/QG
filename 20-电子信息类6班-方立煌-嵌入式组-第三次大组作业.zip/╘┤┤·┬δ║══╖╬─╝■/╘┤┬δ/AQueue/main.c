#include<stdio.h>
#include<stdlib.h>
#include"Aqueue.h"
#include"control.h"
int main() {
	system("cls");
	AQueue* Q = (AQueue*)malloc(sizeof(AQueue));
	if (Q) {
		Q->front = Q->rear = 0;
		Q->length = 0;
		quence_function(Q);
	}
	return 0;
}