#include<stdio.h>
#include<stdlib.h>
#include"LQueue.h"
#include"LControl.h"
#include"Lset.h"
#include<string.h>
void InitLQueue(LQueue* q) {
	Node* p = (Node*)malloc(sizeof(Node));
	if (p == NULL) return;	
	toxy(36, 6);
	printf("----------------------------------------------------------------\n");
	toxy(36, 7);
	printf("|            �������湦����ѡ����������                        |\n");
	toxy(36, 8);
	printf("|            1.int                                             |\n");
	toxy(36, 9);
	printf("|            2.char                                            |\n");
	toxy(36, 10);
	printf("|            3.double                                          |\n");
	toxy(36, 11);
	printf("|            4.������һ��                                      |\n");
	toxy(36, 12);
	printf("----------------------------------------------------------------\n");
	int temp=input(1,4);
	switch (temp) {
	case 1:type = sizeof(int); break;
	case 2:type = sizeof(char); break;
	case 3:type = sizeof(double); break;
	case 4:Lquence_function(q);
	}
	p->next = NULL;
	q->front = p;
	q->rear = p;
	return ;
}
Status IsEmptyLQueue(LQueue* q) {
	return q->front == q->rear ? TRUE : FALSE;
}
Status EnLQueue(LQueue* q, void* e) {
	Node* temp;
	temp = (Node*)malloc(sizeof(Node));
	if (!temp) {
		return FALSE;
	}
	(temp->data) = (void*)malloc(type);
	if (temp->data == NULL)return FALSE;
	memcpy(temp->data, e, type);
	q->rear->next = temp;
	q->rear = temp;
	q->rear->next = NULL;
	return TRUE;
}
Status DeLQueue(LQueue* q) {
	if (q->front == q->rear) {
		return FALSE;
	}
	else if (q->front->next == q->rear) {
		free(q->rear);
		q->front->next= NULL;
		q->rear = q->front;
	}
	else {
		Node* temp = NULL;
		temp = q->front->next;
		q->front->next = temp->next;
		temp->next = NULL;
		free(temp);
	}
	return TRUE;
}
void ClearLQueue(LQueue* q) {
	if (q->front == q->rear) {
		return;
	}
	else {
		Node* temp = NULL;
		temp = q->front->next;
		while (temp) {
			q->front->next = temp->next;
			temp->next = NULL;
			free(temp);
			temp = q->front->next;
		}
		q->rear = q->front;
		return ;
	}
}
void DestoryLQueue(LQueue* q) {
	if (q->front != q->rear) {
		Node* temp = NULL;
		temp = q->front->next;
		while (temp) {
			q->front->next = temp->next;
			temp->next = NULL;
			free(temp);
			temp = q->front->next;
		}
		q->rear = q->front;
	}
	free(q->front);
	q->front = NULL;
	q->rear = NULL;
	type = 0;
}
Status GetHeadLQueue(LQueue* q, void* e) {
	if (q->front == q->rear) {
		return FALSE;
	}
	else {
		memcpy(e, q->front->next->data, type);
		return TRUE;
	}
}
int LengthLQueue(LQueue* q) {
	if (q->front == q->rear) {
		return 0;
	}
	else {
		int count = 0;
		Node* temp = q->front;
		while (temp != q->rear) {
			temp = temp->next;
			count++;
		}
		printf("�ɹ�ִ�в���\n");
		printf("���г���Ϊ��%d\n", count);
		return count;
	}
}
Status TraverseLQueue(LQueue* q, void (*foo)(void* q)) {
	if (q->front == q->rear) {
		return FALSE;
	}
	else {
		Node* temp = q->front->next;
		while (temp != NULL) {
			foo(temp->data);
			temp = temp->next;
		}
		return TRUE;
	}
}
void LPrint(void* q) {

	switch (type) {
		case 1 : printf("%c", *(char*)q); break;
			case 4 : printf("%d", *(int*)q); break;
				case 8 : printf("%f", *(double*)q); break;
	}
	printf("\t");
}
