#include<stdio.h>
#include<stdlib.h>
#include"LControl.h"
#include"LQueue.h"
int main() {
	LQueue* q = (LQueue*)malloc(sizeof(LQueue));
	if (q) {
		q->front = NULL;//ͷβָ��ָ��NULL
		q->rear = NULL;
		type = 0;
		Lquence_function(q);
		system("pause");
	}
	return 0;
}