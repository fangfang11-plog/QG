#pragma once
#include"SqStack.h"
void sqstack_function(SqStack* s);
void back(SqStack* s);
void creat_function(SqStack* s);
void isEmpty_function(SqStack* s);
void getTop_fuction(SqStack* s);
void clear_function(SqStack* s);
void destory_function(SqStack* s);
void length_function(SqStack* s);
void push_function(SqStack* s);
void pop_function(SqStack* s);