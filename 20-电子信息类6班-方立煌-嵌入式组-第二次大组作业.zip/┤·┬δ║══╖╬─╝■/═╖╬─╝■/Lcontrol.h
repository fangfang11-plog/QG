#pragma once
#include"LinkStack.h"

enum Color
{
	black, blue, green, lakeBlue, red, purple, yellow, white, gray,
	lightBlue, lightGreen, lightSimpleGreen, lightRed, lightPurple, lightYellow, brightWhite
};

void linkstack_function(LinkStack* s);
void back(LinkStack * s);
void create_function(LinkStack * s);
void isEmpty_function(LinkStack * s);
void getTop_function(LinkStack * s);
void clear_function(LinkStack * s);
void clear_function(LinkStack * s);
void destory_function(LinkStack * s);
void length_function(LinkStack * s);
void push_function(LinkStack * s);
void pop_function(LinkStack * s);
Status print_Node(LinkStack * s);
void print_function(LinkStack * s);