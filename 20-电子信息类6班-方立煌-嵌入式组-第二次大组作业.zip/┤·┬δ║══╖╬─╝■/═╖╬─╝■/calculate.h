#pragma once
typedef int elemtype;
typedef enum Status {
	SUCCESS=1,
	ERROR=0
}status;
typedef struct Stacknode {
	elemtype data;
	struct Stacknode* next;
}stacknode,*linkstackptr;
typedef struct Linkstack {
	linkstackptr top;
	int count;
}linkstack; 
void calculate_function(linkstack* num, linkstack* ch);
void back(linkstack* num, linkstack* ch);
void function(linkstack* num, linkstack* ch);
status check_string(char* str);
status init_linkstack(linkstack**s);
status push_linkstack(linkstack**s,elemtype);
status pop_linkstack(linkstack**s);
status judge_function(char a);
status isempty_linkstack(linkstack* s);
int option(char a, linkstack* ch);
