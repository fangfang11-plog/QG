#include"sqstack.h"
#include<stdio.h>
#include<stdlib.h>
Status initStack(SqStack* s, int sizes) {
	s->elem = (ElemType*)malloc(sizeof(ElemType) * sizes);
	if (s->elem) {
		s->size = sizes;
		s->top = -1;
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}
Status isEmptyStack(SqStack* s) {
	if (s->top == -1) {
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}
Status getTopStack(SqStack* s, ElemType* e) {
	if (s->top == -1) {
		return ERROR;
	}
	else {
		*e = s->elem[s->top];
		return SUCCESS;
	}
}
Status clearStack(SqStack* s) {
	if (s->top == -1) {
		printf("��ջΪ��ջ");
		return ERROR;
	}
	else {
		s->top = -1;
		return SUCCESS;
	}
}
Status destroyStack(SqStack* s) {
	s->size = 0;
	s->top = -1;
	free(s->elem);
	if (s->size != 0) {
		return ERROR;
	}
	return SUCCESS;
}
Status stackLength(SqStack* s, int* length) {
	if (s->top == -1) {
		return ERROR;
	}
	else {
		(*length) = s->top+1;
		return SUCCESS;
	}
}
Status pushStack(SqStack* s, ElemType e) {
	if (s->top + 1 == s->size) {//�ж��Ƿ�ջ��
		return ERROR;
	}
	else {
		s->elem[++s->top] = e;
		return SUCCESS;
	}
}
Status popStack(SqStack* s, ElemType* e) {
	if (s->top == -1) {//�ж��Ƿ�Ϊ��ջ
		return ERROR;
	}
	else {
		*e = s->elem[s->top];
		s->top--;
		return SUCCESS;
	}
}