#include<stdio.h>
#include<stdlib.h>
#include"SqStack.h"
#include"control.h"
int main() {
	SqStack* s = (SqStack*)malloc(sizeof(SqStack));
	
	if (s) {
		s->size = 0;
		sqstack_function(s);
	}
	system("pause");
	return 0;
}