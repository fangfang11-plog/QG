#include<stdio.h>
#include<stdlib.h>
#include"calculate.h"
int main() {
	system("cls");
	linkstack* num, * ch;
	num = NULL;
	ch = NULL;
	calculate_function(num, ch);
	system("pause");
	return 0;
}