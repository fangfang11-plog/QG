#include<stdio.h>
#include<stdlib.h>
#include"LinkStack.h"
Status initLStack(LinkStack** s) {
	(*s) = (LinkStack*)malloc(sizeof(LinkStack));
	if (!(*s)) {
		return ERROR;
	}
	(*s)->top = NULL;
	(*s)->count = 0;
	return SUCCESS;
}
Status isEmptyLStack(LinkStack* s) {
	if (s->count == 0) {
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}
Status getTopLStack(LinkStack* s, ElemType* e) {
	if (s->count == 0) {
		return ERROR;
	}
	else {
		*e = s->top->data;
		return SUCCESS;
	}
}
Status clearLStack(LinkStack** s) {
	if ((*s)->top) {
		LinkStackPtr temp;
		for (; (*s)->count > 0; (*s)->count--) {
			temp = (*s)->top;
			(*s)->top = (*s)->top->next;
			free(temp);
		}
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}
Status destroyLStack(LinkStack** s) {
	LinkStackPtr temp;
	for (; (*s)->count > 0; (*s)->count--) {
		temp = (*s)->top;
		(*s)->top = (*s)->top->next;
		temp->next = NULL;
		free(temp);
	}
	free((*s));
	(*s) = NULL;
	if ((*s)) {
		return ERROR;
	}
	else {
		return SUCCESS;
	}
}
Status LStackLength(LinkStack* s, int* length) {
	if (s->count != 0) {
		*length = s->count;
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}
Status pushLStack(LinkStack** s, ElemType e) {
	LinkStackPtr temp = (LinkStackPtr)malloc(sizeof(StackNode));
	if (temp == NULL) {
		return ERROR;
	}
	else {
		temp->data = e;
		temp->next = (*s)->top;
		(*s)->top = temp;
		(*s)->count++;
		return SUCCESS;
	}
}
Status popLStack(LinkStack** s, ElemType* e) {
	if ((*s)->count != 0) {
		LinkStackPtr temp;
		*e = (*s)->top->data;
		temp = (*s)->top;
		(*s)->top = (*s)->top->next;
		(*s)->count--;
		free(temp);
		return SUCCESS;
	}
	else {
		return ERROR;
	}
}