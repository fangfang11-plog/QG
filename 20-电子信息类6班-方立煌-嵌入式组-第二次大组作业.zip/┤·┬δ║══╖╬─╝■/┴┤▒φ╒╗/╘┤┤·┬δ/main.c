#include<stdio.h>
#include<stdlib.h>
#include"LinkStack.h"
#include"Lcontrol.h"
int main() {
	LinkStack* s = NULL;
	linkstack_function(s);
	system("pause");
	return 0;
}