#include<reg52.h>

sbit Buzzer = P2^0;

void main(){
   
   while(1){

     Buzzer = 0;

   }

}