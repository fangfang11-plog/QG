#include<reg52.h>
#include<intrins.h>

typedef unsigned int uint;

void DelayMS(uint x)//��ʱ 1ms
{

	uint i;

	while (x--)

	{

		for (i = 0; i < 120; i++);

	}

}


void main(void) {

	uint temp;
	uint count;

	temp = 0Xfe;
	while (1)
	{


		for (count = 0; count < 8; count++) {

			P2 = temp;

			temp = _crol_(temp, 1);

			DelayMS(100);
		}

		temp = 0Xfe;

	}

}
