#pragma once
#define MAXSIZE 1000
typedef enum Status {
	ERROR = 0, SUCCESS = 1
}status;
void back(char* str);
void find_string(char* str);
status find_cc_string(char* str, const int length, char* temp);
void menu(char* str);
void covert_function(char* str);
char* convert(char* str, int num);