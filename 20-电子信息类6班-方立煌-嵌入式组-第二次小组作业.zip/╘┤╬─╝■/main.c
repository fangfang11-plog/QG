#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"mystring.h"
int main() {
	system("cls");
	char str[MAXSIZE];
	menu(str);
}
